Topcoder handle: JonyStorm
https://www.topcoder.com/members/JonyStorm

answer: K-special is 10

Explanation:
For now I found the answer that would be accurate for the highest value of k-special is 10.
Just by drawing and analysis. I provided a photo that was drawn using inkskape. 


For time criteria I'm submitting this. I will try to  submit more precious answer with math 
formula if I can find again.