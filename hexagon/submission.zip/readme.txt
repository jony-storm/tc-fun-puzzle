Topcoder handle: JonyStorm
https://www.topcoder.com/members/JonyStorm

answer: 8 (eight)

Explanation:
For now I found the answer would be accurate for the highest value of k-special is 8.
Just by drawing and analysis. I provided a photo of pen and paper drawing. The drawing is not 
with proper scale but this is just for varifying concepts.


For time criteria I'm submitting this. I will try to  submit more precious answer with math 
formula if I can find again.

