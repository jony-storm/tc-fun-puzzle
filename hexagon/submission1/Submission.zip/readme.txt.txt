Topcoder handle: JonyStorm
https://www.topcoder.com/members/JonyStorm

answer: 6

Explanation:
For now I found the answer would be accurate for the highest value of k-special is 6.
Just by drawing and analysis. I provided a screenshot picture where I draw a hexagon with six
sides approximately of length 1 to 6. I used https://www.mathsisfun.com/geometry/hexagon.html for 
interactive drawing.

So I'm thinking we can precisely draw sides for values 1 to 6 length.

For time criteria I'm submitting this. I will try to  submit more precious answer with math 
formula if I can find again.

